/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sisgestionestudiantes;

// Modelo
class Estudiante {
    public String nombre;
    public int id;
    public double promedio;

    public Estudiante(String nombre, int id, double promedio) {
        this.nombre = nombre;
        this.id = id;
        this.promedio = promedio;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public double getPromedio() { return promedio; }
    public void setPromedio(double promedio) { this.promedio = promedio; }
}

// Vista
class EstudianteVista {
    public void mostrarDetallesEstudiante(String nombre, int id, double promedio) {
        System.out.println("Estudiante: ");
        System.out.println("Nombre: " + nombre);
        System.out.println("ID: " + id);
        System.out.println("Promedio: " + promedio);
    }
}

// Controlador
class EstudianteControlador {
    public Estudiante modelo;
    public EstudianteVista vista;

    public EstudianteControlador(Estudiante modelo, EstudianteVista vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void setEstudianteNombre(String nombre) {
        modelo.setNombre(nombre);
    }

    public String getEstudianteNombre() {
        return modelo.getNombre();
    }

    public void setEstudianteId(int id) {
        modelo.setId(id);
    }

    public int getEstudianteId() {
        return modelo.getId();
    }

    public void setEstudiantePromedio(double promedio) {
        modelo.setPromedio(promedio);
    }

    public double getEstudiantePromedio() {
        return modelo.getPromedio();
    }

    public void actualizarVista() {
        vista.mostrarDetallesEstudiante(modelo.getNombre(), 
                                      modelo.getId(), 
                                      modelo.getPromedio());
    }
}

public class SisGestionEstudiantes {

    public static void main(String[] args) {
        // Obtener datos del estudiante de la base de datos
        Estudiante modelo = new Estudiante("Juan Sanchez", 1, 9.5);

        // Crear la vista para mostrar los datos del estudiante
        EstudianteVista vista = new EstudianteVista();

        // Crear el controlador
        EstudianteControlador controlador = new EstudianteControlador(modelo, vista);

        // Actualizar vista
        controlador.actualizarVista();

        // Actualizar datos del modelo a través del controlador
        controlador.setEstudianteNombre("Juan Carlos Sanchez");
        controlador.setEstudiantePromedio(9.8);

        // Mostrar datos actualizados
        controlador.actualizarVista();

    }
}
