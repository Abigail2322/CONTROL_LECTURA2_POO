/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sisgestionproductos;

import java.util.ArrayList;
import java.util.List;

//Modelo
class Producto {
    public int id;
    public String nombre;
    public double precio;
    public int stock;

    public Producto(int id, String nombre, double precio, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
}

// Vista
class ProductoVista {
    public void mostrarProducto(Producto producto) {
        System.out.println("\nDetalles del Producto:");
        System.out.println("ID: " + producto.getId());
        System.out.println("Nombre: " + producto.getNombre());
        System.out.println("Precio: $" + producto.getPrecio());
        System.out.println("Stock: " + producto.getStock());
    }

    public void mostrarListaProductos(List<Producto> productos) {
        System.out.println("\nLista de Productos:");
        for (Producto producto : productos) {
            System.out.println("ID: " + producto.getId() + 
                             ", Nombre: " + producto.getNombre() + 
                             ", Precio: $" + producto.getPrecio() + 
                             ", Stock: " + producto.getStock());
        }
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println("\nMensaje: " + mensaje);
    }
}

// Controlador
class ProductoControlador {
    public List<Producto> modeloLista;
    public ProductoVista vista;

    public ProductoControlador(List<Producto> modelo, ProductoVista vista) {
        this.modeloLista = modelo;
        this.vista = vista;
    }

    public void agregarProducto(int id, String nombre, double precio, int stock) {
        Producto producto = new Producto(id, nombre, precio, stock);
        modeloLista.add(producto);
        vista.mostrarMensaje("Producto agregado exitosamente");
    }

    public void actualizarProducto(int id, String nombre, double precio, int stock) {
        for (Producto producto : modeloLista) {
            if (producto.getId() == id) {
                producto.setNombre(nombre);
                producto.setPrecio(precio);
                producto.setStock(stock);
                vista.mostrarMensaje("Producto actualizado exitosamente");
                return;
            }
        }
        vista.mostrarMensaje("Producto no encontrado");
    }

    public void eliminarProducto(int id) {
        modeloLista.removeIf(producto -> producto.getId() == id);
        vista.mostrarMensaje("Producto eliminado exitosamente");
    }

    public void mostrarProducto(int id) {
        for (Producto producto : modeloLista) {
            if (producto.getId() == id) {
                vista.mostrarProducto(producto);
                return;
            }
        }
        vista.mostrarMensaje("Producto no encontrado");
    }

    public void mostrarTodosLosProductos() {
        vista.mostrarListaProductos(modeloLista);
    }
}

public class SisGestionProductos {

    public static void main(String[] args) {
        // Crear lista de productos
        List<Producto> listaProductos = new ArrayList<>();
        
        // Crear vista
        ProductoVista vista = new ProductoVista();
        
        // Crear controlador
        ProductoControlador controlador = new ProductoControlador(listaProductos, vista);

        // Agregar productos
        controlador.agregarProducto(1, "Laptop", 999.99, 10);
        controlador.agregarProducto(2, "Mouse", 29.99, 50);
        controlador.agregarProducto(3, "Teclado", 49.99, 30);

        // Mostrar todos los productos
        controlador.mostrarTodosLosProductos();

        // Actualizar un producto
        controlador.actualizarProducto(2, "Mouse Inalambrico", 39.99, 45);

        // Mostrar producto específico
        controlador.mostrarProducto(2);

        // Eliminar un producto
        controlador.eliminarProducto(3);

        // Mostrar lista actualizada
        controlador.mostrarTodosLosProductos();
    }
}
